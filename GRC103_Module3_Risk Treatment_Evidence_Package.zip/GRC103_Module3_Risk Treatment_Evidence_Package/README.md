# GRC103 Module 3 - Technical Risk Treatment Lab: evidence package

Environment: Ubuntu Server 24.04.3 LTS (192.168.60.133) and Kali Linux (192.168.60.128), isolated VMware host-only network, fictional data only.
Time zones: Kali files are WAT (UTC+01:00); Ubuntu logs are UTC. Example: Kali 00:12:10+01:00 = Ubuntu 23:12:10 UTC.
Notes: Ubuntu outputs are provided as screenshots (no file-transfer path from the server was configured). No log lines were edited or invented. All approvals are simulated. SSH was installed temporarily for pasting and removed before the firewall step.

## 

## Evidence map (step to evidence)

|Step|What it shows|Files / screenshots|
|-|-|-|
|1 Prepare Ubuntu|Both adapters up; then NAT disconnected, only host-only active|SS-01 (ip -br addr, NAT up), SS-02 (ens33 DOWN, ens34 192.168.60.133)|
|2-3 Build services|Legacy service active on 8080; Nginx listing on, file retrievable|SS-03, SS-04, configs/nginx-grc-lab-baseline.conf, configs/grc-legacy.service|
|4 Baseline|Ports 80 and 8080 open; listings; file; legacy 200; UFW inactive|kali-evidence/baseline-time.txt, baseline-ports.txt, baseline-web.txt, baseline-listing.txt, baseline-file.txt, baseline-legacy.txt; SS-05 (ufw status, ss -lntp), SS-05b (ls -ld /srv/grc-backups: not found), SS-06|
|5 Risk register|R1-R4 baseline scores|Report Section 2; calc workbook, sheet Risk\_Register|
|6 Avoidance|8080 closed, 80 works, rollback tested, final state refused|kali-evidence/avoidance-time.txt, avoidance-ports.txt, avoidance-legacy.txt, avoidance-portal.txt, final-legacy-time.txt; SS-07, SS-08; report Section 3 (CHG-001, simulated approval)|
|7 Archive hardening|/public/ 200; /archive/, file, / = 403; file root-only|kali-evidence/archive-time.txt, archive-public.txt, archive-listing.txt, archive-file.txt, archive-root.txt; SS-09, SS-10; configs/nginx-grc-lab-final.conf|
|(setup) SSH removed|Port 22 no longer listening; package state rc|SS-11|
|8 UFW|Rule list; allowed 200; blocked timeouts (exit 28)|SS-12, SS-13, SS-14; kali-evidence/ufw-allowed-time.txt, ufw-allowed.txt, ufw-blocked-time.txt; configs/ufw-final-state.txt|
|9 Log correlation|UFW BLOCK lines; Nginx 200/403 from approved IP; 0 entries for 192.168.60.50|SS-15 (ufw.log), SS-16 (Nginx tail + grep -c = 0); kali-evidence/corr-public-time.txt, corr-public.txt, corr-archive-time.txt, corr-archive.txt|
|10 Backup and recovery|Backup + hash; delete; 403; restore; hash OK; 200; timings|SS-17 (Ubuntu sequence), SS-18, SS-19; kali-evidence/recovery-failed-time.txt, recovery-failed.txt, recovery-restored-time.txt, recovery-restored.txt; report Section 6|
|Monitoring|M1-M4 (proposed, not measured)|Report Section 7|
|11 Transfer / acceptance|Managed backup clause; plain HTTP acceptance (simulated)|Report Section 8|
|12 Costs and reassessment|A $150, B $360, C $100; ALE $1,000 / $200 / $800 / net $440; R1-R4 residual|Report Sections 9-10; calc workbook|



